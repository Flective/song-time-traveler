# Fiat Musica Changelog

All notable changes to Fiat Musica are documented here.

---

## [8.1] - 2025-12-09

### Fixed
- **Missing submit button** in Album Builder "Add or Modify Tracks" form - Streamlit was showing error because form_submit_button was inside conditional block
- **Button text contrast** issues in Noir Jazz and Platonic Ideal themes - buttons now readable

### Changed
- **Sidebar navigation** - Replaced large buttons with compact text links, reduced vertical space significantly
- **Page titles** - Replaced placeholder banner system with colored title bars
- **Whitespace** - Reduced excessive padding throughout

### Added
- **Page title color editor** in Settings - Pick colors for each page's title bar
- **Feedback system** in Settings - Report bugs/features, download feedback.json for Claude to review
- **Page instructions** - Collapsible "How to use this page" section at bottom of pages (starting with Album Builder and Settings)
- **CHANGELOG.md** - This file, for tracking version history

### Technical
- Added `PAGE_COLORS_FILE` and `FEEDBACK_FILE` to file paths
- Added `load_page_colors()`, `save_page_colors()`, `render_page_title()` functions
- Added `render_page_instructions()` helper function

---

## [8.0] - 2025-12-09

### Added
- **Audio playback** - Manifestations now have working audio players via `st.audio()`
- **Manifestation categories** - Anchor, Alternate Version, Instrumental/Sync, Demo
- **Triangulation Suites** - Create listening journeys chaining 2-4 manifestations
- **Pro Mode toggle** - Hide admin controls for clean public view
- **Catalog Browser page** - Search/filter catalog with sidebar filters
- **PDF export** - Generate professional sync catalog PDFs (requires fpdf)
- **CSV export** - Always-available catalog export
- **Search & filter** - Filter by title, theme, mood, tempo, category, persona
- **Enhanced metadata** - Duration, mood tags, energy level fields

### Configuration
- `MUSIC_DIR = 'music/'` - Audio files location
- `SUITES_FILE` - Triangulation suites storage

---

## [7.0] - 2025-12-09

### Added
- **Sidebar navigation** - Replaced tab-based navigation with hierarchical sidebar
- **Theme system** - Multiple visual themes (Noir Jazz, Platonic Ideal, Modern Minimal, etc.)
- **Page notes** - Collapsible notes section on each page
- **Page banners** - Configurable banner images per page (placeholder system)

### Changed
- Complete UI restructure from tabs to pages
- Removed 13-tab top navigation

---

## [6.0 and earlier]

Initial development versions with core functionality:
- Virtual Songs (Platonic Ideals)
- Manifestations
- Personas
- My Albums
- Founding Members
- Documentation Library
- Voting system
- Reviews
- Living Archive
- Band HQ
- Artist Outreach
- Protosongs
- Analytics
