# Sync Licensing & Music Placement Guide

## A Strategic Framework for Catalog Commercialization

*Prepared for Jim Gannaway | December 2025*

---

## Your Position: Asset Holder, Not Petitioner

Before diving into tactics, understand your positioning. With 44+ songs validated at professional quality (8.0+/10), you are not in the traditional position of an unknown artist hoping someone will listen to two or three tracks.

**You hold a catalog.** This is a renewable resource that sync agents, music libraries, and publishers actively seek. Their business models depend on having deep inventory. A single-song writer needs them; a catalog owner offers them something they want.

This changes the dynamic:
- You can approach sync libraries and publishers as a potential signing, not a one-off pitch
- You can negotiate terms (non-exclusive vs. exclusive, advance vs. no advance)
- You have leverage because walking away costs them an entire catalog
- They have incentive to develop the relationship because more material is coming

---

## Tier 1: Curated Sync Libraries (High Priority)

These are selective, high-quality libraries that actively pitch to music supervisors. Acceptance itself is validation.

### Marmoset
**Website:** https://www.marmosetmusic.com/submissions
**What they are:** Portland-based boutique sync agency, first certified B Corporation in the music industry. Works with Netflix, major brands, indie filmmakers.
**Why they matter:** Highly curated, strong relationships with supervisors, ethical reputation.
**Submission:** Via their submissions page (check if currently accepting)
**Revenue split:** Not publicly disclosed; negotiate directly
**Best for:** Your atmospheric, sophisticated material (Strange Lullaby, Forever Dripping in the Paint)

### Musicbed
**Website:** https://www.musicbed.com
**What they are:** Premium sync licensing platform serving filmmakers, from indie to Super Bowl commercials.
**Why they matter:** High-quality bar means acceptance validates your work; strong filmmaker relationships.
**Submission:** Currently not accepting new submissions—sign up for notifications at their knowledge base
**Revenue split:** Varies by license type
**Best for:** Emotionally clear tracks with cinematic quality

### Terrorbird Media
**Website:** https://terrorbird.com/licensing
**What they are:** Brooklyn-based sync agency representing indie labels and artists since 2006. Also offers publishing.
**Why they matter:** "Left-of-center" focus, 95% client retention rate, recovered millions in unpaid royalties.
**Clients include:** Netflix, Apple TV+, Paramount, Xbox, Riot Games
**Submission:** Via their website submission form
**Revenue split:** Industry standard (typically 50/50 on sync fees)
**Best for:** Your full catalog—they treat new releases and catalog with equal attention

**Educational Resource:** Josh Briggs (Terrorbird's Head of Publishing) wrote a comprehensive guide: "How to get your music licensed for films, TV, and beyond" at The Creative Independent
https://thecreativeindependent.com/guides/how-to-get-your-music-licensed-for-films-tv-and-beyond

---

## Tier 2: Platform-Based Libraries (Broader Reach)

Less curated than Tier 1, but wider exposure and easier entry.

### Songtradr
**Website:** https://www.songtradr.com
**What they are:** Large-scale music licensing platform with both direct licensing and "Music Wanted" opportunities.
**Why they matter:** Free to upload catalog; AI-powered matching to opportunities; major brand clients (Netflix, Amazon, FOX, NBC, Volkswagen).
**How it works:** Upload tracks, set pricing, respond to "Music Wanted" briefs, opt into Monetization Portal for background music licensing.
**Revenue split:** 60-80% to artist depending on plan level
**Cost:** Free (Starter), $20/year (Lite), $100/year (Pro)
**Best for:** Broad exposure across multiple licensing types; good for building presence

### Artlist
**Website:** https://artlist.io
**What they are:** Subscription-based library primarily serving content creators.
**Why they matter:** Steady income potential from subscription revenue sharing.
**Revenue model:** Artists paid based on usage within subscriber base
**Best for:** Tracks suitable for YouTube creators, podcasters, corporate videos

### Musicvine
**Website:** https://musicvine.com
**What they are:** UK-based curated library, prefers exclusivity but accepts non-exclusive.
**Revenue split:** 60% for exclusive, 35% for non-exclusive
**Best for:** Quality-focused indie material

---

## Tier 3: Feedback & Connection Services

### Groover (You're Already Using This)
**Website:** https://groover.co
**What they are:** Platform connecting artists with 3,000+ curators, including sync supervisors, playlist curators, radio, and labels.
**How it works:** Pay per submission (€2/contact), guaranteed feedback within 7 days or credits returned.
**Why it matters:** Direct access to sync supervisors and publishers alongside playlist/press opportunities.
**Pro tip:** Filter specifically for "sync supervisors" and "publishers" rather than just playlist curators.
**Best for:** Testing individual tracks, building relationships, getting actionable feedback

### Taxi
**Website:** https://www.taxi.com
**What they are:** Independent A&R service since 1992. Screens submissions and forwards qualified material to real industry opportunities.
**Cost:** $299.95/year membership + $5/submission
**How it works:** They publish opportunities (disguised for privacy), you submit, screeners evaluate, qualified submissions forwarded.
**Pros:** Real opportunities, educational feedback, free annual convention (Road Rally)
**Cons:** Mixed reviews on ROI; best for those still developing; some feel it's better for learning than earning
**Best for:** Education about sync market, TV/film placement focus, networking

---

## Revenue Paths Comparison

| Path | Effort Level | Time to First Income | Income Potential | Control |
|------|-------------|---------------------|------------------|---------|
| Curated Library (Marmoset, Musicbed) | Medium | 3-12 months | High ($5K-$50K+ per placement) | Medium |
| Platform Library (Songtradr) | Low | 1-6 months | Low-Medium ($50-$5K) | High |
| Direct Sync Agent | High | 6-18 months | Highest | Low |
| Groover/Feedback Services | Low | Ongoing | Variable | High |
| Spotify/Streaming | Medium | 3-12 months | Low-Medium (volume dependent) | High |
| Artist Covers | High | 12-24 months | Variable (royalties) | Low |

---

## Timeline & Priority Framework

### Month 1-2: Foundation
**Effort: 10-15 hours total**

1. **Identify your top 10 sync-ready tracks** based on Gemini's assessment
2. **Prepare stems and instrumentals** for priority tracks (this is labor, not creative work)
3. **Register with PRO** (ASCAP, BMI, or SESAC) if not already done—required for backend royalties
4. **Create organized catalog document** with metadata: tempo, key, mood, instrumentation, lyrics theme

### Month 2-3: Initial Submissions
**Effort: 5-10 hours total**

1. **Submit to Marmoset and Terrorbird** (Tier 1 curated libraries)
2. **Sign up for Musicbed notifications** for when they reopen
3. **Upload catalog to Songtradr** (Tier 2 platform)
4. **Continue Groover campaigns** targeting sync supervisors specifically

### Month 3-6: Expand & Follow Up
**Effort: 3-5 hours/month ongoing**

1. **Track responses** and follow up on pending submissions
2. **Add more tracks** as you complete production polish
3. **Respond to Music Wanted briefs** on Songtradr
4. **Build relationships** with any curators who respond positively

### Month 6-12: Evaluate & Adjust
1. **Assess ROI** on each channel
2. **Double down** on what's working
3. **Consider Taxi** if you want more education/community
4. **Explore direct supervisor outreach** if you've built some placement history

---

## What You Need Ready

Before approaching any sync opportunity:

### Essential
- **High-quality masters** (WAV, 44.1kHz/16-bit minimum)
- **Instrumental versions** of every track
- **Stems** (separated tracks) for flexibility
- **Clean versions** if any tracks contain profanity
- **Metadata spreadsheet**: Title, Artist, Album, Duration, Tempo (BPM), Key, Mood tags, Instrumentation, Lyrics (full text), One-line description

### Important
- **PRO registration** (ASCAP/BMI/SESAC)
- **Copyright registration** (recommended, not required)
- **One-sheet** describing your catalog (genre range, mood range, comparable artists)

### Nice to Have
- **Short edits** (30-second, 60-second versions)
- **Alternative mixes** (acoustic, stripped, etc.)
- **Press kit** with artist bio and photos

---

## Sync Fee Ranges (Industry Standards)

| Placement Type | Typical Range |
|----------------|---------------|
| Major Film Trailer | $50,000 - $500,000+ |
| National TV Commercial | $25,000 - $500,000 |
| Major Network TV Series | $5,000 - $75,000 |
| Streaming Series (Netflix, etc.) | $2,000 - $25,000 |
| Indie Film | $500 - $5,000 |
| Video Game | $1,000 - $50,000 |
| YouTube/Online Video | $50 - $1,000 |
| Background/Production Music | $50 - $500 per use |

**Note:** These are upfront sync fees only. Backend performance royalties (paid by PROs) can add significant ongoing income, especially for TV placements that get repeated airings.

---

## Educational Resources

### Essential Reading
- **"How to get your music licensed for films, TV, and beyond"** by Josh Briggs (Terrorbird)
  https://thecreativeindependent.com/guides/how-to-get-your-music-licensed-for-films-tv-and-beyond

### YouTube Channels & Videos
- **Ari's Take** - Ari Herstand's channel covers sync licensing extensively
  https://www.youtube.com/user/aristake
- **"Micro Sync Licensing with Musicbed CEO"** - Ari's Take interview
  https://aristake.com/daniel-mccarthy/
- **Taxi TV** - Weekly shows on sync licensing and music business
  https://www.youtube.com/user/TaxiMusicTV

### Courses (If You Want Deep Education)
- **Ari Herstand's "Advanced Sync Strategies for TV, Film, and Video Games"**
  Available at aristake.com

---

## Key Contacts Directory

| Organization | Website | Type |
|-------------|---------|------|
| Terrorbird Media | terrorbird.com | Sync Agency/Publisher |
| Marmoset | marmosetmusic.com | Curated Sync Library |
| Musicbed | musicbed.com | Premium Sync Library |
| Songtradr | songtradr.com | Platform Library |
| Groover | groover.co | Feedback/Connection Service |
| Taxi | taxi.com | A&R/Education Service |
| Artlist | artlist.io | Subscription Library |
| Music Vine | musicvine.com | Curated Library |
| Audiosocket | audiosocket.com | Non-exclusive Library |

---

## Your Specific Advantages

Based on Gemini's sync assessment of your catalog:

**Strongest Sync Candidates:**
1. **Strange Lullaby** (9.0/10) - TOP PRIORITY. Psychological drama, art-house, thrillers.
2. **Getting Closer** (9.0/10) - Prestige advertising, cinematic trailers.
3. **The Door** (8.5/10) - Anthemic trailers, sports montages, driving scenes.
4. **Ooh May May May** (8.5/10) - Versatility asset—comedy, quirky scenes, youth ads.
5. **Don't Wear Your Heart Out** (8.0/10) - 80s period pieces, retro commercials.

**Your Genre Positioning:** Favorable. Atmospheric/Alt-Rock, Sophisticated Pop-Rock, and Indie Folk are frequent targets for sync supervisors seeking texture and narrative depth.

**Production Status:** ~85% broadcast-ready. Prioritize stem separation and final polish on your top 10 before aggressive pitching.

---

## Action Checklist

**This Week:**
- [ ] Identify your top 10 sync-ready tracks
- [ ] Register with ASCAP, BMI, or SESAC (if not done)
- [ ] Create Songtradr account and begin uploading

**This Month:**
- [ ] Prepare stems/instrumentals for top 5 tracks
- [ ] Submit to Terrorbird Media
- [ ] Submit to Marmoset
- [ ] Sign up for Musicbed submission notifications
- [ ] Run Groover campaign targeting sync supervisors

**Next 90 Days:**
- [ ] Complete stem separation for top 10 tracks
- [ ] Respond to at least 5 "Music Wanted" briefs on Songtradr
- [ ] Follow up on all pending submissions
- [ ] Evaluate results and adjust strategy

---

## Final Note

The hard part is done. You've written the songs. The production pipeline—stem separation, final mixing, metadata organization—is labor, not creative problem-solving. It's a checklist.

One major sync placement can exceed a year of streaming revenue. Unlike streaming, sync pays upfront. Your catalog positions you for multiple placements, not a single lottery ticket.

Execute systematically. The music is ready. Now it's about getting it in front of the right people.

---

*Document prepared December 2025*
*Based on research and independent quality assessments*
